﻿using Domain;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.Interface
{
   public interface IRegistration
   {
        Task<userRegistration> userRegistration(userRegistration userRegistration);
        Task<string> UserLogin(Login login);
   }
}
