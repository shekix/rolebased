﻿using Domain;
using Domain.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.Interface
{
    public interface IUser
    {
        Task <IEnumerable<userRegistration>> GetAllUsers ();
        Task<userRegistration> GetUserById (Guid id);
        Task<userRegistration> UpdateUser(Guid id, registrationDto userdto);
        Task<userRegistration> DeleteUser(Guid id);
    }
}
