﻿using core.Interface;
using core.services.Jwt;
using Domain;
using Infrastructure;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.services.Registration
{
    public class registrationService : IRegistration
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _config;
        public registrationService(AppDbContext context , IConfiguration config)
        {
            _context = context;
            _config = config;
        }
        public async Task<userRegistration> userRegistration(userRegistration user)
        {
            var existingUser =  _context.userRegistrations.Where(u => u.Email == user.Email).FirstOrDefault();
            if (existingUser != null)
            {
                return null;
            }
            user.Id = Guid.NewGuid();
            user.CreatedOn = DateTime.Now;
            user.isActive = true;
             await _context.userRegistrations.AddAsync(user);
            _context.SaveChanges();
            return user;
        }
            

        public async Task<string> UserLogin(Login login)
        {

            var userAvailable = _context.userRegistrations.Where(u => u.Email == login.Email).FirstOrDefault();
            if (userAvailable == null) 
            {
                return null;
            }
            if(userAvailable.Password != login.Password)
            {
                return null ;
            }

            var token = await Task.FromResult(new JwtService(_config).GenerateToken(login.Email, new List<string> { userAvailable.Role }));

            return token;
        }
    }
}
